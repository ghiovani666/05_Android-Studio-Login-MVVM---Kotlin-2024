package com.example.loginmvvm01.utils

object Constant {
    const val BASE_URL = "http://10.0.3.2:8000"
}